import React from 'react'

const Footer = () => {
  return (
    <div className='strip bg-dark text-light p-10 w-100 footerstrip'>
      <div className='container text-center fs-5 my-auto'>Eliran Aizik | 2022</div>
    </div>
  )
}

export default Footer