export const apiURL='https://www.omdbapi.com/?apikey=2be62b1&';
export const images=[
    {
        title:'The Master',
        img:'/imgs/1.jpg',
        omdbID:'tt1560747'
    },
    {
        title:'In the Mood for Love',
        img:'/imgs/2.jpg',
        omdbID:'tt0118694'
    },
    {
        title:'Mulholland Drive',
        img:'/imgs/3.jpg',
        omdbID:'tt0166924'
    },
    {
        title:'There Will be Blood',
        img:'/imgs/4.jpg',
        omdbID:'tt0469494'
    },
    {
        title:'The Revenant',
        img:'/imgs/5.jpg',
        omdbID:'tt1663202'
    },
    {
        title:'The Lord of the Rings: The Fellowship of the Ring',
        img:'/imgs/6.jpg',
        omdbID:'tt0120737'
    },
    {
        title:'Phantom Thread',
        img:'/imgs/7.jpg',
        omdbID:'tt5776858'
    }
];