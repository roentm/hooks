import React from 'react'
import Movies from '../pages/Movies'

const Home = () => {
  return (
    <Movies/>
  )
}

export default Home