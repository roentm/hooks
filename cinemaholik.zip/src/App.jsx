import React from 'react'
import './App.css'
import AppRoutes from './routers/appRoutes'

const App = () => {
  return (
    <>
    <AppRoutes/>
    </>
  )
}

export default App